# NusaMedia 2.0 — Node.js + SQLite + cPanel

Source baru dari nol. Tidak menggunakan source NusaMedia lama.

## Cakupan inti
- Account type saat registrasi: Personal, Creator, Business, UMKM, Public Figure.
- Personal tidak diberi form kategori tambahan.
- Creator/Business/UMKM/Public Figure mendapat kategori sesuai jenisnya.
- Akun selalu dibuat dan dapat login; verification adalah lifecycle terpisah.
- Badge verification untuk semua jenis akun; Personal wajib identifikasi saat mengajukan.
- Business/UMKM memiliki data usaha dan approval; approved otomatis mendapat badge.
- Public Figure menampilkan bidang, mis. `Public Figure · Budaya`.
- Profile/Edit Profile menampilkan jenis akun + menu verifikasi.
- Content Safety rule engine untuk pornografi, judi online, narkoba, kekerasan, SARA/hate, spam.
- Post/comment/story/reel/live/product/chat melewati safety rule sebelum publikasi.
- Quarantine + reports + moderation center + audit log.
- Local discovery memakai lokasi yang diberikan user atau lokasi kasar dari IP/provider geolocation yang dikonfigurasi.
- Local trend engine dengan freshness, engagement velocity/engagement, share/save dan local relevance.
- UMKM + Culture discovery foundation.
- Iklan dengan targeting country/province/city; diberi jalur terpisah dari ranking organik.
- Feed, Reels, Stories, Chat, Friends, Marketplace, Wallet, Live lifecycle.
- Admin Center untuk settings, features, moderation, verification, integrations, ads, backup/recovery, plugins, system health, audit.
- SQLite WAL, indexes, pagination, rate limit, session store, transaction DB.
- Protected restore dengan token + confirmation phrase + checksum.

## Batas infrastruktur yang eksplisit
- Payment gateway, SMTP, cloud storage, geolocation API, dan media streaming provider dapat diisi kemudian melalui Admin Center. Source sudah menyediakan integration records, config, test endpoint, signed payment webhook, dan lifecycle adapter.
- Live video ingest/distribution tetap membutuhkan media infrastructure (RTMP/WebRTC/HLS provider/server). Node/SQLite tidak berpura-pura menjadi media server.
- IP geolocation hanya coarse location. Precise GPS hanya jika user memberikan permission.
- SQLite dapat melayani ribuan akun pada beban ringan/moderat jika hosting memadai; throughput write-heavy (chat/live/analytics) dibatasi oleh SQLite/cPanel. Arsitektur memakai WAL, indexing, pagination, dan transaksi agar efisien, tetapi tidak mengklaim kapasitas absolut tanpa load test pada server nyata.

## cPanel
1. Upload/extract source.
2. Jalankan `install.php` sekali untuk membuat `.env`, direktori, dan bootstrap admin.
3. Buat Node.js App di cPanel/Passenger, startup `server.js`, Node >=18.
4. Jalankan `npm install --omit=dev` melalui terminal cPanel jika tersedia.
5. Start/restart Node App.
6. Login Admin Center.
7. Isi provider credentials/integrations dari Admin Center.
8. Setelah setup, rename/delete `install.php`.

## Keamanan
- Jangan menyimpan nomor identitas lengkap. UI hanya meminta 4 digit terakhir pada contoh pengajuan; implementasi produksi dapat memakai identity provider/document vault terpisah.
- Secrets provider jangan ditaruh di source code. Gunakan environment/secret store cPanel atau field secret yang dilindungi pada deployment nyata.
- Restore wajib checksum + confirmation token.
- Plugin manifest divalidasi; Admin Center tidak mengeksekusi arbitrary JS dari browser.

## Local Search, UMKM & Delivery
The `/local.html` experience supports natural-language local discovery such as `lagi laper ni` or `lagi di Bali enaknya beli oleh-oleh apa`. Ranking combines intent, text/category relevance, verification trust, freshness, local area and distance when coordinates are available.

Location policy:
- IP geolocation is coarse and cached; configure the geolocation integration in Admin Center.
- Precise device location is optional and only used after browser permission.
- If no location is available, the system falls back to account country/province/city.

Delivery:
- Orders can request a quote, create a courier order and refresh status.
- A signed delivery webhook is supported.
- Gojek/Grab contracts are not fabricated: Admin Center stores the official merchant endpoint paths and credentials supplied by the operator. This is a completed configurable adapter boundary, not a fake vendor API. Until a provider is enabled and configured, checkout remains available without courier dispatch and the UI reports delivery as unavailable.
