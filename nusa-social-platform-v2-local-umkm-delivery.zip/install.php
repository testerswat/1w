<?php
// cPanel-friendly first-run installer. Node.js must be created via cPanel Node.js App / Passenger.
$base=__DIR__; $dbdir=$base.'/storage/database'; $up=$base.'/storage/uploads'; $back=$base.'/storage/backups'; foreach([$dbdir,$up,$back] as $d){if(!is_dir($d))@mkdir($d,0755,true);}
$msg=''; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $site=trim($_POST['site_name']??'NusaMedia'); $admin=trim($_POST['admin_username']??''); $email=trim($_POST['admin_email']??''); $pass=$_POST['admin_password']??''; $secret=$_POST['session_secret']??bin2hex(random_bytes(40));
  if(!preg_match('/^[a-zA-Z0-9_]{3,30}$/',$admin)||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($pass)<10)$err='Data admin tidak valid. Password minimal 10 karakter.';
  else { $env="NODE_ENV=production
PORT=3000
APP_URL=".($_POST['app_url']??'')."
SESSION_SECRET=".$secret."
TRUST_PROXY=1
DB_PATH=./storage/database/app.sqlite
UPLOAD_DIR=./storage/uploads
BACKUP_DIR=./storage/backups
MAX_UPLOAD_MB=100
";file_put_contents($base.'/.env',$env);file_put_contents($dbdir.'/admin-bootstrap.json',json_encode(['username'=>$admin,'email'=>$email,'password'=>$pass],JSON_PRETTY_PRINT));file_put_contents($base.'/storage/database/installed.json',json_encode(['site_name'=>$site,'installed_at'=>date('c'),'node_required'=>true],JSON_PRETTY_PRINT));$msg='Konfigurasi tersimpan. Jalankan Node App melalui cPanel; bootstrap admin akan dibuat otomatis pada start pertama.'; }
}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Install NusaMedia</title><style>body{font-family:system-ui;background:#f5f5f5;margin:0;padding:25px}.box{max-width:620px;margin:auto;background:#fff;border-radius:18px;padding:22px;box-shadow:0 8px 30px #0001}input{width:100%;padding:12px;box-sizing:border-box;margin:6px 0 12px;border:1px solid #ddd;border-radius:10px}button{background:#e51d2a;color:#fff;border:0;border-radius:10px;padding:12px 18px;font-weight:800}.ok{background:#ecf9ef;padding:12px;border-radius:10px}.err{background:#fff0f1;padding:12px;border-radius:10px}</style></head><body><div class="box"><h1 style="color:#e51d2a">NusaMedia Installer</h1><p>Setup awal untuk Node.js + SQLite + cPanel.</p><?php if($msg):?><div class="ok"><?=$msg?></div><?php endif;?><?php if($err):?><div class="err"><?=$err?></div><?php endif;?><form method="post"><label>Nama situs</label><input name="site_name" value="NusaMedia"><label>URL aplikasi</label><input name="app_url" placeholder="https://domain.com"><h3>Admin pertama</h3><label>Username</label><input name="admin_username" required><label>Email</label><input name="admin_email" type="email" required><label>Password admin</label><input name="admin_password" type="password" minlength="10" required><label>Session secret</label><input name="session_secret" placeholder="Kosongkan untuk generate otomatis"><button>Install / Simpan Konfigurasi</button></form><p style="font-size:13px;color:#777">Setelah Node App aktif, hapus/rename install.php untuk mengurangi attack surface. Installer tidak menjalankan perintah shell dan tidak memberikan OS root.</p></div></body></html>
