const crypto=require('crypto');
function csrfToken(){return crypto.randomBytes(32).toString('hex')}
function sign(payload,secret){return crypto.createHmac('sha256',secret).update(payload).digest('hex')}
function timingSafeEqualHex(a,b){try{const x=Buffer.from(a,'hex'),y=Buffer.from(b,'hex');return x.length===y.length&&crypto.timingSafeEqual(x,y)}catch{return false}}
function rateLimit({windowMs=60000,max=300}={}){const buckets=new Map(); return (req,res,next)=>{const key=(req.ip||'unknown')+':'+req.path,now=Date.now(),b=buckets.get(key); if(!b||now-b.start>windowMs)buckets.set(key,{start:now,count:1}); else {b.count++; if(b.count>max)return res.status(429).json({error:'Terlalu banyak permintaan, coba lagi sebentar.'})} next()}}
function randomToken(n=24){return crypto.randomBytes(n).toString('hex')}
module.exports={csrfToken,sign,timingSafeEqualHex,rateLimit,randomToken};
