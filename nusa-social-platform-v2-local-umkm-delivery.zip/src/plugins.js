function validateManifest(m){if(!m||typeof m!=='object')throw Error('Manifest tidak valid');for(const k of ['name','version','entry'])if(!m[k])throw Error('Manifest membutuhkan '+k);if(!/^[a-z0-9._-]+$/i.test(m.name))throw Error('Nama plugin tidak valid');return true}
module.exports={validateManifest};
