const fs=require('fs'),crypto=require('crypto'),path=require('path');
function createBackup(dbPath,outDir){fs.mkdirSync(outDir,{recursive:true});const target=path.join(outDir,'app-'+new Date().toISOString().replace(/[:.]/g,'-')+'.sqlite');fs.copyFileSync(dbPath,target);const sha=crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex');return {path:target,sha256:sha,size_bytes:fs.statSync(target).size}}
function verifyBackup(file,sha){if(!fs.existsSync(file))return false;return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')===sha}
module.exports={createBackup,verifyBackup};
